package fi.ovatsia.restkilke

data class TrainCategory(
    val name: String
)