package fi.ovatsia.restkilke

data class TrainTypes(
    val name: String,
    val trainCategory: TrainCategory
)